package util;

//De esta clase descenderan las clases practica

public abstract class Practica {

    public abstract void init();
}
